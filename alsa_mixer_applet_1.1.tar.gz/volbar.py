#!/usr/bin/env python

import alsaaudio
import gtk
import egg.trayicon
import pygtk
import gobject
import subprocess
import os

class ProgressBar(gtk.Window):
  def __init__(self, volume):
    gtk.Window.__init__(self, gtk.WINDOW_POPUP);
    self.set_border_width(0)
    self.set_default_size(180, -1)
    self.set_position(gtk.WIN_POS_CENTER)

    timer = gobject.timeout_add(1000, self.destroy)

    bar = gtk.ProgressBar()
    bar.set_fraction(volume/100.0)
    bar.set_orientation(gtk.PROGRESS_LEFT_TO_RIGHT)
    bar.set_text("Volume: "+str(volume)+"%")

    self.add(bar)
    self.show_all()


class Mixer:
  def __init__(self, control, trayicon):
    self.control = control
    self.trayicon = trayicon
  # yes, we always need a new object, stupid alsa :\
  def mixer(self):
    return alsaaudio.Mixer(self.control)

  def muted(self):
    return self.mixer().getmute()[0]

  def toggle(self):
    os.system("alsa_master_mute")
    self.trayicon.update()

  def getvolume(self):
    return self.mixer().getvolume()[0]

  def setvolume(self, volume):
 
    if volume > 100:
      self.mixer().setvolume(100)
    elif volume < 0:
      self.mixer().setvolume(0)
    else:
      self.mixer().setvolume(volume)

    self.trayicon.update()

class TrayIcon:
  def __init__(self):
    self.current_icon=""
    self.trayicon = egg.trayicon.TrayIcon("undo")
    self.icon = gtk.Image()

    self.tray_eventbox = gtk.EventBox()  
    self.tray_eventbox.add(self.icon)
    self.tray_eventbox.connect("button_press_event", self.clicked)
    self.tray_eventbox.connect("scroll-event", self.scrolled)
    self.trayicon.add(self.tray_eventbox)
    self.trayicon.show_all() 
    
    self.mixer = Mixer('Master', self)
    self.update()

    # create stuffs
    self.volume_popup = tray_volume_scale()
    self.volume_popup_exists = False
          
  def update(self):
    volume = self.mixer.getvolume()
    if self.mixer.muted() or volume == 0:
      status = "muted"
    elif volume > 68:
      status = "high"
    elif volume >= 32:
      status = "medium"
    elif volume > 0:
      status = "low"

    if status != self.current_icon:
      self.icon.set_from_icon_name("audio-volume-"+status, 0)
      self.current_icon = status;


  def clicked(self,widget,event):
    if event.button == 1: #left click
	if event.type == gtk.gdk._2BUTTON_PRESS:
		subprocess.Popen("xfce4-mixer")
		self.volume_popup.close()
		self.volume_popup_exists = False
	else:
	      if self.volume_popup_exists:
		self.volume_popup.close()
		self.volume_popup_exists = False
	      else:
		self.volume_popup.create()
		self.volume_popup_exists = True

    elif event.button == 2: #middle click
      self.mixer.toggle()


  def scrolled(self,widget,event):
    if event.direction == gtk.gdk.SCROLL_UP:
      os.system("/usr/local/bin/alsa_master_up")
      self.update()
    elif event.direction == gtk.gdk.SCROLL_DOWN:
      os.system("/usr/local/bin/alsa_master_down")
      self.update()
   
        

#OLD!        
class tray_volume_scale:
    def create(self):
	# create the volume window 
        self.scale_window = gtk.Window(type=gtk.WINDOW_POPUP)

	# declare the window width based on the trayicon's size
	self.window_width = voltray.icon.window.get_size()[0]

	# declare the window height
        self.window_height = 150

	# get the volume window coordinates
        coordinates = self.get_tray_coordinates(voltray.icon,self.window_height,self.window_width)
        
	# place the window to the coordinates
        self.scale_window.move(coordinates[0],coordinates[1])
    
	# create the volume scale widget object
        self.scale = gtk.VScale()

	# define it's features
        self.scale.set_update_policy(gtk.UPDATE_CONTINUOUS)
        self.scale.set_digits(1)
        self.scale.set_value_pos(gtk.POS_TOP)
        self.scale.set_draw_value(False)
        self.scale.set_inverted(True)
        self.scale.set_range(0,100)

	# size the volume scale to the window's size
        self.scale.set_size_request(self.window_width,self.window_height)

	# set the actual volume scale value to the actual volume value
        self.scale.set_value(voltray.mixer.getvolume())

	# connect the "move" event to it's handler
        self.scale.connect("motion_notify_event", self.setted)
#        self.scale_window.connect('focus-out-event',self.close)  
	# add the volume scale to the volume window
        self.scale_window.add(self.scale)

	# show the volume window
        self.scale_window.show_all()
        
    def get_tray_coordinates(self,trayicon,window_height,windows_width):
        """
        http://www.daa.com.au/pipermail/pygtk/2006-February/011837.html
        get the trayicon coordinates to send to
        notification-daemon
        trayicon=egg.trayicon.TrayIcon
        return : [x,y]
        """
        coordinates=trayicon.window.get_origin()
        size=trayicon.window.get_size()
        screen=trayicon.window.get_screen()
        screen_height=screen.get_height()


	# if the trayicon is less than 180 under the upper screen border, place the volume window under the trayicon
	# if not, place it over the trayicon
	if coordinates[1] <= window_height:
            y=coordinates[1]+size[1]
        else:
            y=coordinates[1]-window_height

        msg_xy=(coordinates[0],y)
        return msg_xy
        
        
    def close(self):

        self.scale_window.destroy()
        
    
    def setted(self,widget,event):
        voltray.mixer.setvolume(int(self.scale.get_value()))
        voltray.update()

if __name__ == "__main__":
    voltray = TrayIcon()
    gtk.main()
